# fantasy_armor 日本語化パック

## 対応バージョン
- Minecraft: 1.20.1
- MOD ID: fantasy_armor

## 導入方法
1. このzipファイルをMinecraftの「リソースパック」フォルダに入れる
   - Windowsの場合: %appdata%\.minecraft\resourcepacks
   - Macの場合: ~/Library/Application Support/minecraft/resourcepacks
2. Minecraftを起動し、「設定」→「リソースパック」を開く
3. このパックを「使用中」に移動して適用

## ビルド情報
- ビルド日: 2026/1/9
- 配布元: https://ykpiece.github.io/minecraft-ja-packs/

## ライセンス
この翻訳は個人利用・配信・動画投稿すべてOKです。
再配布する場合は配布元へのリンクをお願いします。

## 問題報告
不具合や翻訳の改善提案は以下へお願いします：
https://github.com/ykpiece/minecraft-ja-packs/issues
