# silentlib 日本語化パック

## 対応バージョン
- Minecraft: 1.20.1
- MOD ID: silentlib

## 導入方法
1. タイトル画面から「設定」を開き、「リソースパック」をクリックする。
2. 画面下の「パックフォルダーを開く」をクリックし、開いたresourcepacksフォルダの中にzipファイルごと入れる
3. このパックを「選択可能」から「使用中」に移動して適用する

## ビルド情報
- ビルド日: 2026/1/10
- 配布元: https://ykpiece.github.io/minecraft-ja-packs/

## ライセンス
この翻訳は個人利用・配信・動画投稿すべてOKです。
再配布する場合は配布元へのリンクをお願いします。

## 問題報告
不具合や翻訳の改善提案は以下へお願いします：
https://github.com/ykpiece/minecraft-ja-packs/issues

# 寄付
もしこの日本語化パックが役に立ったら、支援していただけると励みになります。
https://buymeacoffee.com/piece
